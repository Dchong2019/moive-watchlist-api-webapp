# Movies Watchlist

## About

Search for your favourite movies and save it in a watchlist. and create an account to login to the site 


## Instructions

No install is needed.

## Built with
- HTML.
- CSS.
- JavaScript.

